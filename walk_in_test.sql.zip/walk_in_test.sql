-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Sep 03, 2015 at 05:10 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `walk_in_test`
--
CREATE DATABASE IF NOT EXISTS `walk_in_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `walk_in_test`;

-- --------------------------------------------------------

--
-- Table structure for table `activities_users`
--

CREATE TABLE IF NOT EXISTS `activities_users` (
  `activity_id` bigint(11) NOT NULL,
  `user_id` bigint(11) NOT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activities_users`
--

INSERT INTO `activities_users` (`activity_id`, `user_id`, `id`) VALUES
(83, 109, 2),
(84, 110, 3),
(85, 110, 4),
(104, 131, 6),
(105, 132, 7),
(106, 132, 8),
(108, 153, 10),
(109, 154, 11),
(110, 154, 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities_users`
--
ALTER TABLE `activities_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities_users`
--
ALTER TABLE `activities_users`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
