-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Sep 03, 2015 at 09:35 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `walk_in_test`
--
CREATE DATABASE IF NOT EXISTS `walk_in_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `walk_in_test`;

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE IF NOT EXISTS `activities` (
  `activity_name` varchar(255) NOT NULL,
  `activity_date` date NOT NULL,
  `activity_location` varchar(255) NOT NULL,
  `activity_description` varchar(500) NOT NULL,
  `activity_price` varchar(255) NOT NULL,
  `activity_quantity` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `activity_category_id` int(11) NOT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `activities_businesses`
--

CREATE TABLE IF NOT EXISTS `activities_businesses` (
  `activity_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `activities_categories`
--

CREATE TABLE IF NOT EXISTS `activities_categories` (
  `id` bigint(20) unsigned NOT NULL,
  `activity_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activities_categories`
--

INSERT INTO `activities_categories` (`id`, `activity_id`, `category_id`) VALUES
(2, 17, 10),
(3, 18, 11),
(4, 19, 11),
(6, 40, 23),
(7, 41, 24),
(8, 42, 24),
(10, 72, 36),
(11, 73, 37),
(12, 74, 37),
(14, 92, 49),
(15, 93, 50),
(16, 94, 50);

-- --------------------------------------------------------

--
-- Table structure for table `activities_users`
--

CREATE TABLE IF NOT EXISTS `activities_users` (
  `activity_id` bigint(11) NOT NULL,
  `user_id` bigint(11) NOT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activities_users`
--

INSERT INTO `activities_users` (`activity_id`, `user_id`, `id`) VALUES
(22, 23, 3),
(23, 23, 4),
(45, 46, 7),
(46, 46, 8),
(77, 78, 11),
(78, 78, 12),
(96, 0, 14),
(97, 98, 15),
(98, 98, 16);

-- --------------------------------------------------------

--
-- Table structure for table `businesses`
--

CREATE TABLE IF NOT EXISTS `businesses` (
  `business_name` varchar(255) DEFAULT NULL,
  `business_phone` varchar(11) DEFAULT NULL,
  `business_contact` varchar(255) DEFAULT NULL,
  `business_website` varchar(255) DEFAULT NULL,
  `business_address` varchar(255) DEFAULT NULL,
  `business_contact_email` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `businesses`
--

INSERT INTO `businesses` (`business_name`, `business_phone`, `business_contact`, `business_website`, `business_address`, `business_contact_email`, `id`) VALUES
('Apple', '5033133131', 'john', 'walkins.com', '123 fake st', 'me@fakeemail.com', 7),
('IBM', '5033133131', 'john', 'walkins.com', '123 fake st', 'me@fakeemail.com', 8),
('IBM', '5033133131', 'john', 'walkins.com', '123 fake st', 'me@fakeemail.com', 9),
('Smoke Signals', '5033139999', 'Theo', 'Signal.com', '123 getreal st', 'me@realemail.com', 10);

-- --------------------------------------------------------

--
-- Table structure for table `businesses_categories`
--

CREATE TABLE IF NOT EXISTS `businesses_categories` (
  `id` bigint(20) unsigned NOT NULL,
  `business_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `businesses_categories`
--

INSERT INTO `businesses_categories` (`id`, `business_id`, `category_id`) VALUES
(1, 0, 12),
(2, 0, 13),
(3, 0, 13),
(4, 0, 25),
(5, 0, 26),
(6, 0, 26),
(7, 0, 38),
(8, 0, 39),
(9, 0, 39),
(10, 8, 51),
(11, 9, 52),
(12, 10, 52);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) unsigned NOT NULL,
  `category_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_name` varchar(255) DEFAULT NULL,
  `user_phone` bigint(11) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `activities_businesses`
--
ALTER TABLE `activities_businesses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activities_categories`
--
ALTER TABLE `activities_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `activities_users`
--
ALTER TABLE `activities_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `businesses`
--
ALTER TABLE `businesses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `businesses_categories`
--
ALTER TABLE `businesses_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=99;
--
-- AUTO_INCREMENT for table `activities_businesses`
--
ALTER TABLE `activities_businesses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `activities_categories`
--
ALTER TABLE `activities_categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `activities_users`
--
ALTER TABLE `activities_users`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `businesses`
--
ALTER TABLE `businesses`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `businesses_categories`
--
ALTER TABLE `businesses_categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
